/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ScalzottoEdoardo.Tris;

import org.springframework.stereotype.Service;

@Service
public class GameService {
    private String[] board = {"", "", "", "", "", "", "", "", ""};
    private String currentPlayer = "X";
    private boolean gameOver = false;
    private String statusMessage = ""; 

    public String[] getBoard() {
        return board;
    }

    public String getCurrentPlayer() {
        return currentPlayer;
    }

    public boolean isGameOver() {
        return gameOver;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public String makeMove(int index) {
        if (index < 0 || index >= board.length) {
            return "Mossa non valida!";
        }

        if (!gameOver && board[index].equals("")) {
            board[index] = currentPlayer;
            if (checkWin()) {
                gameOver = true;
                statusMessage = "🎉 Vittoria! Il giocatore " + currentPlayer + " ha vinto!";
                return statusMessage;
            } else if (!String.join("", board).contains("")) {
                gameOver = true;
                statusMessage = "😲 Pareggio! Nessuno ha vinto.";
                return statusMessage;
            } else {
                currentPlayer = currentPlayer.equals("X") ? "O" : "X";
                statusMessage = "Turno del giocatore: " + currentPlayer;
            }
        }
        return statusMessage;
    }

    private boolean checkWin() {
        int[][] winningCombinations = {
                {0, 1, 2}, {3, 4, 5}, {6, 7, 8},
                {0, 3, 6}, {1, 4, 7}, {2, 5, 8},
                {0, 4, 8}, {2, 4, 6}
        };
        for (int[] combo : winningCombinations) {
            if (!board[combo[0]].equals("") &&
                board[combo[0]].equals(board[combo[1]]) &&
                board[combo[1]].equals(board[combo[2]])) {
                return true;
            }
        }
        return false;
    }

    public void resetGame() {
        board = new String[]{"", "", "", "", "", "", "", "", ""};
        currentPlayer = "X";
        gameOver = false;
        statusMessage = "Inizia una nuova partita! Turno del giocatore X.";
    }
}