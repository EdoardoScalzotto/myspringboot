package com.ScalzottoEdoardo.Tris;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrisApplication {
    public static void main(String[] args) {
        SpringApplication.run(TrisApplication.class, args);
    }
}   