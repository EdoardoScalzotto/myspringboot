/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ScalzottoEdoardo.Tris;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/game")
public class GameController {
    private final GameService gameService;

    public GameController(GameService gameService) {
        this.gameService = gameService;
    }

    @GetMapping
    public String showGame(Model model) {
        model.addAttribute("board", gameService.getBoard());
        model.addAttribute("currentPlayer", gameService.getCurrentPlayer());
        model.addAttribute("gameOver", gameService.isGameOver());
        model.addAttribute("status", gameService.getStatusMessage()); 
        return "index";
    }

    @PostMapping("/move")
    public String makeMove(@RequestParam int index) {
        gameService.makeMove(index);
        return "redirect:/game";
    }

    @PostMapping("/reset")
    public String resetGame() {
        gameService.resetGame();
        return "redirect:/game";
    }
}